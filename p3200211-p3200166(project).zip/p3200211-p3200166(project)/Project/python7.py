import psycopg2
import numpy as np
import matplotlib.pyplot as plt



# Update connection string information

host = "p3200211-p3200166.postgres.database.azure.com"
user = "examiner@p3200211-p3200166"
dbname = "backupbase"
password = "Agapatealilous13"
sslmode = "require"
# Construct connection string

conn_string = "host={0} user={1} dbname={2} password={3} sslmode={4}".format(host, user, dbname, password, sslmode)
conn = psycopg2.connect(conn_string)
print("Connection established")

cursor = conn.cursor()

lst = []

cursor.execute("SELECT user_id, COUNT (rating) as RatingsCount FROM ratings GROUP by user_id ORDER BY RatingsCount")  
rows = cursor.fetchall()

for row in rows :
    
    
    lst.append((row))
   


x , y  = zip(*lst)
    


plt.xlabel('user_id')
plt.ylabel('AverageRating')
plt.scatter(x, y,s=1)
plt.show()


conn.commit()
cursor.close()
conn.close()