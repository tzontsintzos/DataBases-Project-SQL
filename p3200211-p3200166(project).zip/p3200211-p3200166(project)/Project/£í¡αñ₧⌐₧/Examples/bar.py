import numpy as np
import matplotlib.pyplot as plt
x=[1,2,3,4,5]
y=[7,10,11,23,13]
plt.xlabel('x Axis')
plt.ylabel('y Axis')
plt.bar(x,y)
plt.show()
