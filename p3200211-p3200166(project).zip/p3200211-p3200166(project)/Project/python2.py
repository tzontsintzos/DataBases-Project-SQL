import psycopg2
import numpy as np
import matplotlib.pyplot as plt
import psycopg2.extras

# Update connection string information

host = "p3200211-p3200166.postgres.database.azure.com"
user = "examiner@p3200211-p3200166"
dbname = "backupbase"
password = "Agapatealilous13"
sslmode = "require"

# Construct connection string

conn_string = "host={0} user={1} dbname={2} password={3} sslmode={4}".format(host, user, dbname, password, sslmode)
conn = psycopg2.connect(conn_string)
print("Connection established")

cursor = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)

lstn = []
lstm = []

cursor.execute("SELECT genre.name , COUNT(movie_genres.genre_id) AS moviespergenre FROM genre  INNER JOIN movie_genres on genre.id = movie_genres.genre_id  GROUP BY genre.name ")
rows = cursor.fetchall()

for row in rows :
    
    
    lstn.append(str(row['name']))
    lstm.append(int(row['moviespergenre']))
   

    
plt.bar(lstn, lstm)
plt.xticks(rotation=90)
plt.xlabel('Genre')
plt.ylabel('MoviesPerGenre')
plt.show()

conn.commit()
cursor.close()
conn.close()