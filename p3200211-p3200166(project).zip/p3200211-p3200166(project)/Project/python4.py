import psycopg2
import numpy as np
import matplotlib.pyplot as plt
import psycopg2.extras

# Update connection string information

host = "p3200211-p3200166.postgres.database.azure.com"
user = "examiner@p3200211-p3200166"
dbname = "backupbase"
password = "Agapatealilous13"
sslmode = "require"

# Construct connection string

conn_string = "host={0} user={1} dbname={2} password={3} sslmode={4}".format(host, user, dbname, password, sslmode)
conn = psycopg2.connect(conn_string)
print("Connection established")

cursor = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)

lsty = []
lstmb = []

cursor.execute("SELECT (EXTRACT(YEAR FROM release_date) ) AS year, MAX (budget) as MaxBudget FROM movie WHERE release_date IS NOT NULL GROUP by year ORDER BY year") 
rows = cursor.fetchall()

for row in rows :
    
    lsty.append(int(row['year']))
    lstmb.append(int(row['maxbudget']))
   

    
plt.bar(lsty,lstmb)
plt.xlabel('Year')
plt.ylabel('MaxBudget(in 100s millions)')
plt.show()

conn.commit()
cursor.close()
conn.close()