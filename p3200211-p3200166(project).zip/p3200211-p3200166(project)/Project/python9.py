import psycopg2
import numpy as np
import matplotlib.pyplot as plt


# Update connection string information

host = "p3200211-p3200166.postgres.database.azure.com"
user = "examiner@p3200211-p3200166"
dbname = "backupbase"
password = "Agapatealilous13"
sslmode = "require"
# Construct connection string

conn_string = "host={0} user={1} dbname={2} password={3} sslmode={4}".format(host, user, dbname, password, sslmode)
conn = psycopg2.connect(conn_string)
print("Connection established")

cursor = conn.cursor()

lst = []

cursor.execute("SELECT name , AVG (rating) as AVGrating FROM genre as g INNER JOIN movie_genres as mg on g.id = mg.genre_id INNER JOIN ratings as r on r.movie_id = mg.movie_id GROUP by name ORDER BY AVGrating")  
rows = cursor.fetchall()

for row in rows :
    
    
    lst.append((row))
   
#print (lst)
    
plt.bar(range(len(lst)), [val[1] for val in lst], align='center')
plt.xticks(range(len(lst)), [val[0] for val in lst])
plt.xticks(rotation=90)
plt.xlabel('Genre')
plt.ylabel('AverageRating')
plt.show()

conn.commit()
cursor.close()
conn.close()