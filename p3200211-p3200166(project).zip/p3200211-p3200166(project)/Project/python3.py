import psycopg2
import numpy as np
import matplotlib.pyplot as plt
import psycopg2.extras


# Update connection string information

host = "p3200211-p3200166.postgres.database.azure.com"
user = "examiner@p3200211-p3200166"
dbname = "backupbase"
password = "Agapatealilous13"
sslmode = "require"

# Construct connection string

conn_string = "host={0} user={1} dbname={2} password={3} sslmode={4}".format(host, user, dbname, password, sslmode)
conn = psycopg2.connect(conn_string)
print("Connection established")

cursor = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
lst = []
xVal = []
yVal = []
zVal = []

cursor.execute("SELECT   genre.name , COUNT(movie_genres.genre_id) AS moviespergenre , CAST((EXTRACT(YEAR FROM movie.release_date) ) AS bigint )AS Year  FROM genre  INNER JOIN movie_genres on genre.id = movie_genres.genre_id  INNER JOIN movie on movie.id = movie_genres.movie_id WHERE movie.release_date IS NOT NULL GROUP BY genre.name ,  year ORDER BY year")

rows = cursor.fetchall()

for row in rows :

   
    xVal.append((row['name']))
    zVal.append((row['moviespergenre']))
    yVal.append(int(row['year']))
   


# Initializing Figure
fig = plt.figure()
ax1 = fig.add_subplot(111, projection='3d')
ax1.set_facecolor((1.0, 1.0, 1.0))
# Creating a dictionary from categories to x-axis coordinates
xCategories = xVal
i=0
xDict = {}
x=[]
for category in xCategories:
  if category not in xDict:
    xDict[category]=i
    x.append(i)
    i+=1
  else:
    x.append(xDict[category])
# Defining the starting position of each bar (x is already defined)
z = np.zeros(len(x))
# Defining the length/width/height of each bar.
dx = np.ones(len(x))*0.1
dy = np.ones(len(x))
dz = zVal
ax1.bar3d(x, yVal, z, dx, dy, dz)
ax1.set_zlim([0, max(zVal)])
plt.xticks(range(len(xDict.values())), xDict.keys())
plt.xlabel('Genres')
plt.ylabel('Year')

plt.show()


conn.commit()
cursor.close()
conn.close()