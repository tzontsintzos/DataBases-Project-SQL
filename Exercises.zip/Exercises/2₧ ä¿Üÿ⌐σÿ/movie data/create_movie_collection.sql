create table Movie_Collection(
   movie_id int,
   collection_id int
);