import csv, ast

file = open("keywords.csv",encoding= 'utf8')
csvreader = csv.reader(file)
f1 = open("Keyword.csv", 'w',encoding= 'utf8',newline = '')
f2 = open("Movie_keywords.csv",'w',encoding= 'utf8',newline = '' )
writer1 = csv.writer(f1, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
writer2 = csv.writer(f2, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
r1 =['id','name']
r2 = ['movie_id','keyword_id']
writer1.writerow(r1)
writer2.writerow(r2)
header = next(csvreader)
for row in csvreader:
    movie_id=row[0]
    data = ast.literal_eval(row[1])
    for d in data:
        writer1.writerow([d['id'],d['name']])
        writer2.writerow([movie_id,d['id']])    
f1.close()
f2.close()
file.close()   










