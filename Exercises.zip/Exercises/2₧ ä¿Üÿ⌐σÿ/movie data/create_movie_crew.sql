create table Movie_Crew(
   movie_id int,
   department varchar(20),
   gender int,
   person_id int,
   job varchar(60),
   name varchar(40)
);