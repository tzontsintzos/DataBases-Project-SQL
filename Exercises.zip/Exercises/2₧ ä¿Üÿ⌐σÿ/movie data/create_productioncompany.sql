create table Productioncompany(
   id int,
   name varchar(100)
);