create table Movie_Cast(
   movie_id int,
   cast_id int,
   character varchar(390),
   gender int,
   person_id int,
   name varchar(40)
);