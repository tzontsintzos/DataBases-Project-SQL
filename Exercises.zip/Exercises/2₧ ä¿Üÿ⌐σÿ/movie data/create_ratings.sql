create table Ratings(
   user_id int,
   movie_id int,
   rating varchar(10)
);