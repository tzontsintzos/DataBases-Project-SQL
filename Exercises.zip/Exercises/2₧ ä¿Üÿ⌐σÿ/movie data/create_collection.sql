create table Collection(
   id int,
   name varchar(60)
);