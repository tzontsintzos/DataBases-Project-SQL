create table Movie_Productioncompanies(
   movie_id int,
   pc_id int
);