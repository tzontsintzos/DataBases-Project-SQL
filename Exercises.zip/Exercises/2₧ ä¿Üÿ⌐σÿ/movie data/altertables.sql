ALTER TABLE movie_crew
ADD FOREIGN KEY(movie_id) REFERENCES movie(id);
ALTER TABLE ratings 
ADD FOREIGN KEY(movie_id) REFERENCES movie(id);
ALTER TABLE movie_productioncompanies
ADD FOREIGN KEY(movie_id) REFERENCES movie(id);
ALTER TABLE movie_productioncompanies
ADD FOREIGN KEY(pc_id) REFERENCES productioncompany(id);
ALTER TABLE movie_genres
ADD FOREIGN KEY(movie_id) REFERENCES movie(id);
ALTER TABLE movie_genres
ADD FOREIGN KEY(genre_id) REFERENCES genre(id);
ALTER TABLE movie_cast
ADD FOREIGN KEY(movie_id) REFERENCES movie(id);
ALTER TABLE movie_collection
ADD FOREIGN KEY(movie_id) REFERENCES movie(id);
ALTER TABLE movie_collection
ADD FOREIGN KEY(collection_id) REFERENCES collection(id);
ALTER TABLE movie_collection
ADD FOREIGN KEY(movie_id) REFERENCES movie(id);
ALTER TABLE Movie_Keywords
ADD FOREIGN KEY(keyword_id) REFERENCES Keyword(id);
