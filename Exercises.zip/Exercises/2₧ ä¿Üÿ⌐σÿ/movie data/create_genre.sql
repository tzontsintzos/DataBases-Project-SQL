create table Genre(
   id int,
   name varchar(40)
);