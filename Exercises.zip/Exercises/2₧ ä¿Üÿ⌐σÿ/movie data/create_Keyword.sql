create table Keyword(
   id int,
   name varchar(50)
);