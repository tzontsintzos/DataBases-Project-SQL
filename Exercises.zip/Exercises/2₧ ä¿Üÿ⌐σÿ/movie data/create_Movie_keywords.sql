create table Movie_Keywords(
   movie_id int,
   keyword_id int
);