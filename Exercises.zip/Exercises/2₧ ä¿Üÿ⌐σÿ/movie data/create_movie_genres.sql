create table Movie_Genres(
   movie_id int,
   genre_id int
);