CREATE TABLE Collection(id integer,name varchar);
