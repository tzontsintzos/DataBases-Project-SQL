CREATE TABLE Collection(id integer,name 255);
