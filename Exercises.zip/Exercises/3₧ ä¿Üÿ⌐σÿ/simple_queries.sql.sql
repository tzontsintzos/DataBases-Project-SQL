-1-

/* “Βρες μου τους τίτλους των τοπ 5 ταινιών στις οποιες συμμετεχει ο Ταραντινο καθως και τη δημοτικοτητα της καθεμιας
Εμφανισε τες σε φθινουσα σειρα.

Output: 5 rows
*/

ALTER TABLE movie ALTER COLUMN popularity
TYPE float USING (popularity::float);


SELECT DISTINCT title, popularity 
FROM movie
JOIN movie_crew
ON id = movie_id
WHERE name = 'Quentin Tarantino'
ORDER BY popularity DESC
LIMIT 5;

--------------------------------------------------------------
-2-

/*Βρες μου τους ρολους που εχει παιξει καθε ενας απο τους 'Bruce Willis', 'Madonna' ,  'Antonio Banderas' 
ομαδοποιημενα.
Output: 97 rows
*/

SELECT name , character 
FROM movie_cast
WHERE  name = 'Bruce Willis' OR name = 'Madonna' OR name = 'Antonio Banderas'
ORDER BY name

------------------------------------------------------------------------------
-3-

/*Βρες μου τα συνολικα εσοδα και εξοδα των ταινιων με βαση τη γλωσσα που χρησιμοποιειται (εκτος της αγγλικης)
Output: 46 rows
*/


ALTER TABLE movie ALTER COLUMN revenue
TYPE float USING (revenue::float);

SELECT original_language , SUM(revenue/1000000) AS TotalRevenue_in_millions , SUM(budget) AS TotalBudget_in_millions
FROM movie
WHERE original_language!='en'
GROUP BY original_language
------------------------------------------------------------------------------
-4-

/*Βρες μου τους τιτλους ταινιων με μηδενικο μπατζετ και μεση αξιολογηση απο 3 και πανω
Output: 25 rows
*/


ALTER TABLE movie ALTER COLUMN budget
TYPE int USING (popularity::int);

ALTER TABLE ratings ALTER COLUMN rating
TYPE float USING (rating::float);


SELECT m.title, avg(r.rating) as avgRating , m.budget
FROM movie m
INNER JOIN ratings r
ON m.id = r.movie_id
GROUP BY m.id, m.title
HAVING avg(r.rating)>=3
	AND m.budget=0

------------------------------------------------------------------------------------------------------
-5-

/*Βρες μου τους τιτλους ταινιων ειδους "Animation" με εσοδα ανω των 20 εκατομμυριων
Output: 94 rows
*/

ALTER TABLE movie ALTER COLUMN revenue
TYPE float USING (revenue::float);

SELECT DISTINCT m.title , m.revenue 
FROM movie m,
 movie_genres mg,
 genre g
WHERE g.id = mg.genre_id
 AND m.id = mg.movie_id
 AND g.name = 'Animation'
GROUP BY m.title , m.revenue
HAVING m.revenue > 20000000

---------------------------------------------------------------------------------------
-6-

/*Βρες μου τους τιτλους ταινιων που κυκλοφορησαν το 2002 και δωσε μου τον μεσο ορο των κριτικων,
τη μικροτερη κριτικη,τη μεγαλυτερη κριτικη,το πληθος των κριτικων και την ακριβη ημερομηνια κυκλοφοριας
Output: 492 rows
*/


ALTER TABLE ratings ALTER COLUMN rating
TYPE float USING (rating::float);

ALTER TABLE movie ALTER COLUMN release_date
TYPE date USING (release_date::date);

SELECT DISTINCT m.title , AVG(r.rating) AS avg_Rating , MIN(r.rating) AS Worst_Rating , MAX(r.rating) AS Best_Rating , COUNT(r.rating) AS Number_Of_Ratings , m.release_date
FROM movie m
FULL OUTER JOIN ratings r
ON m.id = r.movie_id
WHERE m.release_date BETWEEN '1/1/2002' AND '12/31/2002'
GROUP BY m.release_date , m.title

-------------------------------------------------------------------------------------------------------------
-7-

/*Βρες μου τους τιτλους ταινιων , οι οποιες εχουν ως λεξη κλειδι λεξεις που ξεκινουν απο "z"
Output: 87 rows
*/


SELECT DISTINCT m.title , k.name , k.id AS keyword_id , mk.movie_id 
FROM movie_keywords mk ,
	 movie m ,
	 keyword2 k
WHERE mk.keyword_id = k.id 
	AND m.id = mk.movie_id 
	AND k.name LIKE 'z%' 
ORDER BY k.name

----------------------------------------------------------------------------------------------------------------
-8-

/*Δωσε μου το πληθος των λεξεων-κλειδιων που εχει η καθε ταινια
Output: 9985 rows
*/

SELECT mk.movie_id , m.title ,  COUNT(mk.movie_id) AS number_of_keywords 
FROM movie_keywords mk
FULL OUTER JOIN movie m 
ON m.id = mk.movie_id
GROUP BY mk.movie_id,m.title
ORDER BY m.title

-----------------------------------------------------------------------------------------------------------------
-9-

/*Βρες τους τιτλους ταινιων δρασης που ειχαν αρνητικο ισοζυγιο (εσοδα-μπατζετ) και δωσε το ισοζυγιο
Output: 1020 rows
*/


ALTER TABLE movie ALTER COLUMN budget
TYPE float USING (budget::float);

ALTER TABLE movie ALTER COLUMN revenue
TYPE float USING (revenue::float);


SELECT DISTINCT m.id,m.title,  SUM(m.revenue-m.budget*1000000)/1000000 AS balance_in_millions 
FROM genre g
JOIN movie_genres mg
ON g.id = mg.genre_id
JOIN movie m
ON m.id = mg.movie_id
WHERE (revenue - budget*1000000)/1000000 < 0
	AND g.name = 'Action'
GROUP BY m.id, g.name
ORDER BY balance_in_millions ASC

-------------------------------------------------------------------------------------------------------------------
-10-

/*Βρες τους τιτλους ταινιων οι οποιες ειναι παραγωγης της 'Paramount Pictures'
Output:540 rows
*/

SELECT DISTINCT mpc.movie_id ,m.title
FROM productioncompany pc
JOIN movie_productioncompanies mpc 
ON pc.id = mpc.pc_id
JOIN movie m 
ON m.id = mpc.movie_id
WHERE pc.name = 'Paramount Pictures'
ORDER BY mpc.movie_id

-------------------------------------------------------------------------------------------------------
-11-

/*Βρες τους τιτλους ταινιων που ανηκουν στο 'Harry Potter Collection' και εμφανισε τους σε αυξουσα σειρα 
με βαση τη δημοτικοτητα
Output:3 rows
*/

SELECT DISTINCT c.name , mc.movie_id ,m.title, m.popularity 
FROM collection c
JOIN movie_collection mc
ON c.id = mc.collection_id
JOIN movie m 
ON m.id = mc.movie_id
WHERE c.name = 'Harry Potter Collection'
ORDER BY m.popularity

---------------------------------------------------------------------------------------------------------
-12-

/*Βρες τις τοπ 20 ταινιες με βαση τα κερδη στις οποιες εχει συμμετασχει στα εφε ο David Allen
Output:20 rows
*/


ALTER TABLE movie ALTER COLUMN budget
TYPE int USING (budget::int);

ALTER TABLE movie ALTER COLUMN revenue
TYPE int USING (revenue::int);

SELECT DISTINCT mc.movie_id ,m.title, SUM(m.revenue-m.budget*1000000)/1000000 AS winnings_in_millions , m.revenue/1000000 AS revenue_in_millions , m.budget AS budget_in_millions
FROM movie_crew mc
INNER JOIN movie m 
ON m.id = mc.movie_id
WHERE mc.name = 'David Allen' AND mc.job = 'Visual Effects'
GROUP BY mc.movie_id , m.title , m.revenue , m.budget
ORDER BY winnings_in_millions DESC
LIMIT 20

















 













